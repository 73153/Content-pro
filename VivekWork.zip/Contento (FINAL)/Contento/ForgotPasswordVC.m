//
//  ForgotPasswordVC.m
//  Contento
//
//  Created by vivek on 10/06/16.
//  Copyright © 2016 Zaptech. All rights reserved.
//

#import "ForgotPasswordVC.h"
#import "Constants.h"

@interface ForgotPasswordVC ()

@end

@implementation ForgotPasswordVC

-(void)viewDidLoad {
    [super viewDidLoad];
    [self.view setBackgroundColor:THEME_BG_COLOR];
    
}
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
}

- (IBAction)btnSignInPressed:(id)sender {
    BOOL isValid=true;
    Globals *sharedManager;
    sharedManager=[Globals sharedManager];
    
    if ([Validations isEmpty:self.txtEmail.text] || ![Validations isValidEmail:self.txtEmail.text]) {
        isValid=false;
        [Globals ShowAlertWithTitle:@"Error" Message:ERROR_EMAIL];
    }
    
    
    if(isValid)
    {
        if([Validations isconnectedToInternet])
        {
            //                sharedManager.user.website=[self.txtWebsite.text mutableCopy];
            sharedManager.user.email=[self.txtEmail.text mutableCopy];
            //                sharedManager.user.jobtitle=[self.txtJobTitle.text mutableCopy];
            //                sharedManager.user.phonenumber=[self.txtPhoneNumber.text mutableCopy];
            [sharedManager showLoaderIn:self.view];
            
            [sharedManager.user authenticate:^(NSString *str, int status){
                
                if(status==1)
                {
                    
                    [sharedManager.user forgotPassword:^(NSString *str, int status){
                        if([str isEqualToString:@"Check your email id for further instructions"]){
                            NSLog(@"change password");
                            [sharedManager hideLoader];
                            
                            UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"Success" message:@"Check your email id for further instructions" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles: nil];
                            [alert show];
                        }
                        
                        else{
                            [sharedManager hideLoader];
                            
                            [Globals ShowAlertWithTitle:@"Success" Message:str ];
                        }
                    }];
                }
                else{
                    [sharedManager hideLoader];
                    [Globals ShowAlertWithTitle:@"Error" Message:str ];
                }
            }];
            
            
        }
        else{
            [Globals ShowAlertWithTitle:@"Error" Message:ERROR_INTERNET];
        }
    }
    //
}

- (IBAction)btnBackTapped:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationForgotPasswordVC].
 // Pass the selected object to the new view controller.
 }
 */

@end
