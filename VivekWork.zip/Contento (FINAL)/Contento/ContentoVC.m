//
//  ContentoVC.m
//  Contento
//
//  Created by aadil on 03/11/15.
//  Copyright © 2015 Zaptech. All rights reserved.
//

#import "ContentoVC.h"

@interface ContentoVC ()

@end

@implementation ContentoVC

- (void)viewDidLoad {
    [super viewDidLoad];
//    [self.btnMenu addTarget:[SlideNavigationController sharedInstance] action:@selector(toggleLeftMenu) forControlEvents:UIControlEventTouchUpInside];
    [self.btnMenu addTarget:self action:@selector(openMenu) forControlEvents:UIControlEventTouchUpInside];
    [SlideNavigationController sharedInstance].enableShadow = false;
    self.sharedManager=[Globals sharedManager];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (BOOL)slideNavigationControllerShouldDisplayLeftMenu
{
    return YES;
}
-(void) openMenu{
    [[SlideNavigationController sharedInstance] toggleLeftMenu];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
