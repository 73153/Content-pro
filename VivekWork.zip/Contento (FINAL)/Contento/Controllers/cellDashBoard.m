//
//  cellDashBoard.m
//  Contento
//
//  Created by aakil on 10/30/15.
//  Copyright © 2015 Zaptech. All rights reserved.
//

#import "cellDashBoard.h"

@implementation cellDashBoard

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
