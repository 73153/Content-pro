//
//  CellTopics.h
//  Contento
//
//  Created by aadil on 10/12/15.
//  Copyright © 2015 Zaptech. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CellTopics : UITableViewCell
@property IBOutlet UILabel *titleLabel;
@property IBOutlet UIButton *addToSelected;
@property BOOL isSelected;
@end
