//
//  SearchVC.h
//  Contento
//
//  Created by aadil on 09/12/15.
//  Copyright © 2015 Zaptech. All rights reserved.
//
#import <UIKit/UIKit.h>
#import <SlideNavigationController.h>
#import "Constants.h"
#import "AppDelegate.h"
#import "CellArticle.h"
#import "ArticleDetailVC.h"
#import <SDWebImage/UIImageView+WebCache.h>
#import "CategoryButtons.h"
#import "ArticalListVC.h"
#import "TopicsVC.h"
#import <YTPlayerView.h>
#import <MediaPlayer/MediaPlayer.h>
@interface SearchVC : UIViewController<UITableViewDelegate,UITableViewDataSource, UISearchControllerDelegate, UISearchBarDelegate, UISearchDisplayDelegate, UISearchResultsUpdating,SlideNavigationControllerDelegate, YTPlayerViewDelegate, MPMediaPickerControllerDelegate, MPMediaPlayback>
{
    IBOutlet UITableView *tblView;
    IBOutlet UISearchBar *searchBar;
    IBOutlet UIButton *btnSearch;
    IBOutlet UIView *headerView,*buttonView;
    UIView *tmpView;
    NSMutableArray *channelList,*articleListArray,*searchResults,*commonArray,*blogListArray, *videoListArray;
    BOOL isSearch,canAnimate;
    UIRefreshControl *refreshControl;
    IBOutlet UIScrollView *scrollView;
    IBOutlet UIImageView *bannerImg;
    CGRect imgViewFrame;
    CGRect initialFrame;
    CGRect headerViewFrame;
    CGFloat sizes;
    IBOutlet UILabel *bannerTitle,*bannerDescription;
    BOOL isSearchTable;
}
@property NSString *searchstr;
@property IBOutlet UIButton *btnMenu,*btnHMenu;
@property IBOutlet YTPlayerView *playerView;
@property IBOutlet UILabel *noData,*searchResults;
@property NSMutableArray  *articleListArray, *videoListArray, *blogListArray;
@property IBOutlet UIView *headerView;
@end
