//
//  CellReadingList.m
//  Contento
//
//  Created by Aadil on 03/11/15.
//  Copyright © 2015 Zaptech. All rights reserved.
//

#import "CellArticle.h"

@implementation CellArticle

- (void)awakeFromNib {
//    self.isCategoryPresent=false;
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
