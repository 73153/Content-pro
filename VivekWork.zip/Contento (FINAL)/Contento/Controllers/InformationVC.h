//
//  InformationVC.h
//  Contento
//
//  Created by aadil on 11/12/15.
//  Copyright © 2015 Zaptech. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Constants.h"
@interface InformationVC : UIViewController
@property NSString *title;
@property IBOutlet UILabel *titleLabel;
@property IBOutlet UIView *headerView;
@property NSString *content;
@property IBOutlet UIWebView *webView;
@end
