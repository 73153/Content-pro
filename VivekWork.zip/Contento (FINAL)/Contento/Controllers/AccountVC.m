//
//  AccountVC.m
//  Contento
//
//  Created by aadil on 16/12/15.
//  Copyright © 2015 Zaptech. All rights reserved.
//

#import "AccountVC.h"

@interface AccountVC ()

@end

@implementation AccountVC

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initVC];
    
    Globals *sharedManager;
    sharedManager=[Globals sharedManager];
    [sharedManager showLoaderIn:self.view];
    [sharedManager.user getRegisterUserProfile:^(NSString *str, int status) {
        if(status==1){
            NSLog(@"Get profile");
            [sharedManager hideLoader];
            
            self.txtFirstName.text = sharedManager.user.firstName;
            //            self.txtFirstName.text = sharedManager.user.lastName;
            self.txtCompany.text = sharedManager.user.company;
            self.txtEmail.text = sharedManager.user.email;
            [self.txtEmail setEnabled:false];
            [self.txtEmail setTextColor:[UIColor lightGrayColor]];
            self.txtPassword.secureTextEntry=YES;
            //            self.txtPassword.text = @"12345678";
            
        }
        
        else{
            [Globals ShowAlertWithTitle:@"Error" Message:str ];
        }
    }];
    // Do any additional setup after loading the view.
}
-(void)initVC{
    CALayer *border = [CALayer layer];
    CGFloat borderWidth = 2;
    border.borderColor = [UIColor darkGrayColor].CGColor;
    border.frame = CGRectMake(0, self.txtFirstName.frame.size.height - borderWidth, self.txtFirstName.frame.size.width, self.txtFirstName.frame.size.height);
    border.backgroundColor = (__bridge CGColorRef _Nullable)([UIColor darkGrayColor]);
    border.borderWidth = borderWidth;
    [self.view setBackgroundColor:THEME_INNER_BG_COLOR];
    [self.btnDone setBackgroundColor:THEME_INNER_BG_COLOR];
    
}
-(IBAction)btndone:(id)sender{
    BOOL isValid=true;
    Globals *sharedManager;
    sharedManager=[Globals sharedManager];
    
    if ([Validations isEmpty:self.txtEmail.text] || ![Validations isValidEmail:self.txtEmail.text]) {
        isValid=false;
        [Globals ShowAlertWithTitle:@"Error" Message:ERROR_EMAIL];
    }
    else if([Validations isEmpty:self.txtFirstName.text] || ![Validations isValidUnicodeName:self.txtFirstName.text]){
        isValid=false;
        [Globals ShowAlertWithTitle:@"Error" Message:ERROR_NAME];
    }
    //    else if([Validations isEmpty:self.txtCompany.text] || ![Validations isValidUnicodeName:self.txtCompany.text]){
    //        isValid=false;
    //        [Globals ShowAlertWithTitle:@"Error" Message:ERROR_COMPANY];
    //    }
    
    
    // Checking if the validation is OK
    
    if(isValid)
    {
        if([Validations isconnectedToInternet])
        {
            sharedManager.user.name=[self.txtFirstName.text mutableCopy];
            sharedManager.user.company=[self.txtCompany.text mutableCopy];
            //                sharedManager.user.website=[self.txtWebsite.text mutableCopy];
            sharedManager.user.email=[self.txtEmail.text mutableCopy];
            //                sharedManager.user.jobtitle=[self.txtJobTitle.text mutableCopy];
            //                sharedManager.user.phonenumber=[self.txtPhoneNumber.text mutableCopy];
            if(self.txtPassword.text.length>0)
                sharedManager.user.password=[self.txtPassword.text mutableCopy];
            [sharedManager showLoaderIn:self.view];
            
            [sharedManager.user updateRegisterUser:^(NSString *str, int status){
                if(status==1){
                    NSLog(@"Update profile");
                    [sharedManager hideLoader];
                    
                    Globals *sharedManager;
                    sharedManager=[Globals sharedManager];
                    [sharedManager.user getRegisterUserProfile:^(NSString *msg, int status) {
                        if(sharedManager.user==nil)
                        {
                            sharedManager.user = [[Users alloc] init];
                        }
                        
                    }];
                    
                    UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"Success" message:SUCCESS_USER_UPDATE delegate:self cancelButtonTitle:@"Ok" otherButtonTitles: nil];
                    [alert show];
                    
                }
                
                else{
                    [Globals ShowAlertWithTitle:@"Error" Message:str ];
                }
            }];
            
        }
        else{
            [Globals ShowAlertWithTitle:@"Error" Message:ERROR_INTERNET];
        }
    }
    //
    
}
-(IBAction)btnclose:(id)sender{
    [self dismissViewControllerAnimated:YES completion:^{
        //
    }];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
