//
//  SearchVC.m
//  Contento
//
//  Created by aadil on 09/12/15.
//  Copyright © 2015 Zaptech. All rights reserved.
//

#import "SearchVC.h"

@interface SearchVC ()

@end

@implementation SearchVC
-(void)viewWillAppear:(BOOL)animated{
    [self.noData setHidden:YES];
    [super viewWillAppear:animated];
     [searchBar setBackgroundImage:[UIImage new]];
    [self.searchDisplayController setActive:NO];
    [self searchBarCancelButtonClicked:self.searchDisplayController.searchBar];
    Globals *sharedManager;
    sharedManager=[Globals sharedManager];
    [sharedManager showLoader];
    
    [self.btnMenu addTarget:[SlideNavigationController sharedInstance] action:@selector(toggleLeftMenu) forControlEvents:UIControlEventTouchUpInside];
    [self.btnHMenu addTarget:[SlideNavigationController sharedInstance] action:@selector(toggleLeftMenu) forControlEvents:UIControlEventTouchUpInside];
    [SlideNavigationController sharedInstance].enableShadow = false;
    [self initVC];
    sharedManager.articlecount=[[sharedManager.db selectAllQueryWithTableName:@"articles"] count];
    // Checking for cached data
    if([commonArray count] == 0)
    {
        
        // Getting List of Articles for particular channels
        articleListArray=[Articles parseArrayToObjectsWithArray:[sharedManager.db selectWhereQueryWithTableName:@"articles" andORDERBYString:@"order by id desc"]];
        
        // Converting Articles to comman array
        for (int i=0; i<[articleListArray count]; i++) {
            NSDictionary *dic=[[NSDictionary alloc] initWithObjects:@[[articleListArray objectAtIndex:i],@"Articles"] forKeys:@[@"data",@"type"]];
            [commonArray addObject:dic];
        }
        
        
        // Getting List of Blogs for particular channels
        blogListArray=[Blogs parseArrayToObjectsWithArray:[sharedManager.db selectWhereQueryWithTableName:@"blogs" andORDERBYString:@"order by id desc"]];
        
        // Converting Blogs to common array
        for (int i=0; i<[blogListArray count]; i++) {
            NSDictionary *dic=[[NSDictionary alloc] initWithObjects:@[[blogListArray objectAtIndex:i],@"Blog"] forKeys:@[@"data",@"type"]];
            [commonArray addObject:dic];
        }
        
        
        
        // Getting List of Videos for particular channels
        videoListArray=[Video parseArrayToObjectsWithArray:[sharedManager.db selectWhereQueryWithTableName:@"videos" andORDERBYString:@"order by id desc"]];
        
        // Converting Video to common array
        for (int i=0; i<[videoListArray count]; i++) {
            NSDictionary *dic=[[NSDictionary alloc] initWithObjects:@[[videoListArray objectAtIndex:i],@"Video"] forKeys:@[@"data",@"type"]];
            [commonArray addObject:dic];
        }
        
        [tblView reloadData];
        [sharedManager hideLoader];
        
       
    }
    else{
        [tblView reloadData];
        [tblView scrollsToTop];
        [sharedManager hideLoader];
    }
    
    [sharedManager.sync getAllReadingListWithCompletionBlock:^(NSArray *result, NSString *str, int status) {
        if(status==1)
        {
            sharedManager.readingListArray=[result mutableCopy];
        }
        else{
            [Globals ShowAlertWithTitle:@"Error" Message:str];
        }
    }];
    
    if (self.searchstr) {
        self.searchDisplayController.active = YES;
        [self.searchDisplayController setActive:YES animated:YES];
        [searchBar setText:self.searchstr];
        [self.searchDisplayController.searchBar becomeFirstResponder];
        [self.searchDisplayController.searchBar setText:self.searchstr];
        [self.searchDisplayController.searchResultsTableView reloadData];
        self.searchDisplayController.searchResultsTableView.rowHeight = UITableViewAutomaticDimension ;
        [searchBar becomeFirstResponder];
        [self filterContentForSearchText:self.searchstr
                                   scope:[[self.searchDisplayController.searchBar scopeButtonTitles]
                                          objectAtIndex:[self.searchDisplayController.searchBar
                                                         selectedScopeButtonIndex]]];

        [tblView reloadData];
        [self.searchDisplayController.searchBar setFrame:CGRectMake(self.searchDisplayController.searchBar.frame.origin.x, self.searchDisplayController.searchBar.frame.origin.y, self.searchDisplayController.searchBar.frame.size.width-32, self.searchDisplayController.searchBar.frame.size.height)];
        //[self searchDisplayControllerDidEndSearch:self];
        //[self searchBar:searchBar textDidChange:self.searchstr];
        //[tblView reloadData];
        
    }
    else{
        [self.searchDisplayController setActive:NO];
        [self searchBarCancelButtonClicked:self.searchDisplayController.searchBar];
    }
}
- (void)searchDisplayController:(UISearchDisplayController *)controller
 willShowSearchResultsTableView:(UITableView *)tableView
{
    [tableView setRowHeight:[tblView rowHeight]];
    [tableView reloadData];
    [self.searchResults setText:[NSString stringWithFormat:@"%d Results",[searchResults count] ]];
    tableView.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];

}
-(void) showAnimation{
    // With Completion
    [UIView animateWithDuration:0.4f animations:^(void){
        tblView.alpha = 1.0f;
        [tblView setFrame:CGRectMake(0, self.view.frame.size.height, self.view.frame.size.width, self.view.frame.size.height)];
    }completion:^(BOOL finished) {
        [tblView setFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height)];
    }];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    [self manageActivity];
    [self.headerView setBackgroundColor:THEME_INNER_BG_COLOR];
    // Do any additional setup after loading the view.
}

-(void) initVC{
    
    self.edgesForExtendedLayout = UIRectEdgeNone;
    AppDelegate *app=(AppDelegate *)[[UIApplication sharedApplication] delegate];
    
    
    [app setMenu];
    [self.searchDisplayController.searchResultsTableView registerClass:[CellArticle class]
                                                forCellReuseIdentifier:@"cellArticle"];
    tmpView=[[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 50)];
    [tmpView setBackgroundColor:[UIColor colorWithRed:201.0f/255.0f green:201.0f/255.0f blue:206.0f/255.0f alpha:1 ] ];
    [self.view addSubview:tmpView];
    [tmpView setHidden:YES];
    tblView.sectionIndexBackgroundColor=[UIColor clearColor];
    [self.searchDisplayController.searchResultsTableView setFrame:CGRectMake(0, 0, tblView.frame.size.width, tblView.frame.size.height)];
    //[self performSelector:@selector(hideSearchBar) withObject:nil afterDelay:0.0f];
    tblView.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
    self.searchDisplayController.searchResultsTableView.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
    //self.searchDisplayController.displaysSearchBarInNavigationBar=YES;
    
    searchResults=MArray;
    commonArray=MArray;
    videoListArray=MArray;
    blogListArray=MArray;
    searchBar.frame=CGRectMake(searchBar.frame.origin.x, searchBar.frame.origin.y, self.view.frame.size.width, 44);
    canAnimate=true;
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(closedFullScreen) name:UIWindowDidBecomeHiddenNotification object:nil];
    
}
-(void)closedFullScreen{
    [self.playerView removeFromSuperview];
}
-(void)manageActivity{
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    //[dateFormat setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss"];
    [dateFormat setDateFormat:@"yyyy-MM-dd"];
    NSTimeZone *timeZone = [NSTimeZone timeZoneWithName:@"UTC"];
    [dateFormat setTimeZone:timeZone];
    NSDate *now = [NSDate date];
    NSString* myString = [dateFormat stringFromDate:now];
    NSMutableDictionary *dic=[[NSMutableDictionary alloc] initWithObjects:@[self.searchstr,@"search",myString] forKeys:@[@"title",@"logType",@"timestamp"]];

//    NSMutableDictionary *dic=[[NSMutableDictionary alloc] initWithObjects:@[self.currentChannel.clientId,self.currentChannel.uuid,self.currentChannel.channelId,self.currentChannel.label,@"viewChannel",myString] forKeys:@[@"clientId",@"objectId",@"channelId",@"title",@"logType",@"timestamp"]];
    //    for (int i=0; i<=[self.currentArticle.meta.tags count]; i++) {
    //        //
    //        [dic setObject:[self.currentArticle.meta.tags objectAtIndex:i] forKey:@"topics"];
    //    }
    Activities *activity=[[Activities alloc] init];
    [activity saveActivity:dic withCompletion:^(NSDictionary *result, NSString *str, int status) {
        if (status==1) {
            //
        }
    }];
}
-(IBAction)searchClicked
{
    [searchBar setHidden:NO];
    [btnSearch setHidden:YES];
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    if ( isSearch) {
         [self.searchResults setText:[NSString stringWithFormat:@"%d Results",[searchResults count] ]];
        return [searchResults count];
        
    }
    else{
         [self.searchResults setText:[NSString stringWithFormat:@"%d Results",[commonArray count] ]];
        return [commonArray count];
    }
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

//------------------------------------------------------------------------
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 0;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *CellIdentifier = @"cellArticle";
    CellArticle *cell;
    if (indexPath.row==0) {
        //        cell =[[CellArticle alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cellArticle"] ;
        cell=[tblView dequeueReusableCellWithIdentifier:@"cellArticle" forIndexPath:indexPath];
    }
    else
    {
        cell =[tblView dequeueReusableCellWithIdentifier:CellIdentifier];
    }
    if (cell == nil) {
        if (indexPath.row==0) {
            cell =[[CellArticle alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cellArticle"];
        }
        else{
            cell =[[CellArticle alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cellArticle"] ;
        }
    }
    [cell.btnDigitalEnterprise setTitleColor:THEME_TAG_COLOR forState:UIControlStateNormal ];
    if ([commonArray count] == 0) {
        // If there are no articles to display than we set default text
        [cell.txtTitle setText:@"No Content Found"];
        [cell.txtDesc setText:@"There are no content available for this channel"];
        [cell.imgContent setImage:[UIImage imageNamed:@"placeholder"]];
        [cell.videoIcon setHidden:YES];
    }
    else if ([searchResults count] == 0 && isSearch) {
        // If there are no articles to display than we set default text
        [cell.txtTitle setText:@"No Articles Found"];
        [cell.txtDesc setText:@"There are no articles available for this channel"];
        [cell.imgContent setImage:[UIImage imageNamed:@"placeholder"]];
        [cell.videoIcon setHidden:YES];
    }
    else{
        // Setting up the Values to the cell if there are articles available
        [cell.videoIcon setHidden:YES];
       
        Articles *tmpArticle;
        Blogs *tmpBlog;
        Video *tmpVideo;
        NSDictionary *tmpDic=[[NSDictionary alloc] init];
        if(!isSearch)
        {
            tmpDic=[commonArray objectAtIndex:indexPath.row];
            
        }
        else{
            tmpDic=[searchResults objectAtIndex:indexPath.row];
        }
            if ([[tmpDic valueForKey:@"type"] isEqualToString:@"Articles"]) {
             tmpArticle=[tmpDic objectForKey:@"data"];;
                
                [cell.txtTitle setText:tmpArticle.title];
                [cell.txtDesc setText:tmpArticle.summary];
                [cell.imgContent sd_setImageWithURL:[NSURL URLWithString:[tmpArticle.imageUrls valueForKey:@"thumbnail"]] placeholderImage:[UIImage imageNamed:@"placeholder"] options:SDWebImageRefreshCached];
//                [cell.imgContent sd_setImageWithURL:[NSURL URLWithString:[tmpArticle.imageUrls valueForKey:@"thumbnail"]]
//                                   placeholderImage:[UIImage imageNamed:@"placeholder"]];
                
                float ypos=cell.txtDesc.frame.origin.y +  [self heightNeededForText:cell.txtDesc.text withFont:[UIFont fontWithName:@"Lato-Regular" size:12.0] width:cell.txtDesc.frame.size.width lineBreakMode:NSLineBreakByWordWrapping];
                float xpos=cell.txtDesc.frame.origin.x;
                CGRect frame=CGRectMake(5, 5, 50, 23);
                for(UIView *subview in cell.contentView.subviews)
                {
                    if([subview isKindOfClass: [CategoryButtons class]])
                    {
                        [subview removeFromSuperview];
                    }
                }
                int heightForCategory=23;
                //tmpBlog.meta.category = @[@"Category 1",@"Category 2",@"Cat 3"] ;
                Globals *sharedManager=[Globals sharedManager];
                tmpArticle.isCategoryPresent=false;
                if ([self getTopicWithUUDI:tmpArticle.topicId]) {
                    Topics *highlightedTopic=[self getTopicWithUUDI:tmpArticle.topicId];
                    [cell.btnDigitalEnterprise setTitle:[highlightedTopic.topicname uppercaseString] forState:UIControlStateNormal] ;
                    tmpArticle.isCategoryPresent=true;
                    cell.btnDigitalEnterprise.tag=indexPath.row+1000;
                    tmpArticle.currentTopic=highlightedTopic;
                    [cell.btnDigitalEnterprise addTarget:self action:@selector(redirectToCategory:) forControlEvents:UIControlEventTouchUpInside];
                }
                else{
                    for(int i=0; i<[sharedManager.topicsArray count]; i++)
                    {
                        Topics *tempTopic=(Topics *)[sharedManager.topicsArray objectAtIndex:i];
                        for (int j=0; j<[tempTopic.channelId count]; j++) {
                            if ([[tempTopic.channelId objectAtIndex:j] isEqualToString:tmpArticle.channelId]) {
                                tmpArticle.isCategoryPresent=true;
                                tmpArticle.topicId=tempTopic.topicId;
                                tmpArticle.currentTopic=tempTopic;
                                CategoryButtons *btn=[[CategoryButtons alloc] init];
                                btn.name=[NSString stringWithFormat:@"%@",tempTopic.topicname];
                                [btn setTitle:[tempTopic.topicname uppercaseString] forState:UIControlStateNormal] ;
                                [cell.btnDigitalEnterprise setTitle:[tempTopic.topicname uppercaseString] forState:UIControlStateNormal] ;
                                
                                frame.size.width=[self widthNeededForText:[tempTopic.topicname uppercaseString] withFont:[UIFont fontWithName:@"Lato-Regular" size:12.0] height:cell.frame.size.width lineBreakMode:NSLineBreakByWordWrapping]+10;
                                [btn.titleLabel setFont: [btn.titleLabel.font fontWithSize: 12.0]];
                                [btn setTitleColor:[UIColor colorWithRed:(188.0f/255.0f) green:(182.0f/255.0f) blue:(11.0f/255.0f) alpha:1.0] forState:UIControlStateNormal  ];
                                btn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
                                btn.frame=frame;
                                [btn addTarget:self action:@selector(redirectToCategory:) forControlEvents:UIControlEventTouchUpInside];
                                cell.btnDigitalEnterprise.tag=indexPath.row+1000;
                                [cell.btnDigitalEnterprise addTarget:self action:@selector(redirectToCategory:) forControlEvents:UIControlEventTouchUpInside];
                                if (i%2==0) {
                                    xpos=xpos+frame.size.width+20;
                                    frame.origin.x=xpos;
                                }
                                else{
                                    ypos=ypos+110;
                                    frame.origin.y=ypos;
                                }
                                cell.categoryView.frame=CGRectMake(cell.categoryView.frame.origin.x, cell.categoryView.frame.origin.y, cell.categoryView.frame.size.width, ypos);
                                // [cell.categoryView addSubview:btn];
                            }
                        }
                        
                    }
                }
                if (!tmpArticle.isCategoryPresent) {
                    [cell.btnDigitalEnterprise setHidden:YES];
                }
                else{
                    [cell.btnDigitalEnterprise setHidden:NO];
                }
                cell.heightForCategory=heightForCategory;

                
            }
            else if ([[tmpDic valueForKey:@"type"] isEqualToString:@"Blog"]) {
             tmpBlog=[tmpDic objectForKey:@"data"];
                [cell.txtTitle setText:tmpBlog.title];
                [cell.txtDesc setText:tmpBlog.summary];
                
                [cell.imgContent sd_setImageWithURL:[NSURL URLWithString:tmpBlog.heroImage]
                                   placeholderImage:[UIImage imageNamed:@"placeholder"] options:SDWebImageRefreshCached];
                
                float ypos=cell.txtDesc.frame.origin.y +  [self heightNeededForText:cell.txtDesc.text withFont:[UIFont fontWithName:@"Lato-Regular" size:12.0] width:cell.txtDesc.frame.size.width lineBreakMode:NSLineBreakByWordWrapping];
                float xpos=cell.txtDesc.frame.origin.x;
                CGRect frame=CGRectMake(5, 5, 50, 23);
                for(UIView *subview in cell.contentView.subviews)
                {
                    if([subview isKindOfClass: [CategoryButtons class]])
                    {
                        [subview removeFromSuperview];
                    }
                }
                int heightForCategory=23;
                //tmpBlog.meta.category = @[@"Category 1",@"Category 2",@"Cat 3"] ;
                Globals *sharedManager=[Globals sharedManager];
                tmpBlog.isCategoryPresent=false;
                if ([self getTopicWithUUDI:tmpBlog.topicId]) {
                    Topics *highlightedTopic=[self getTopicWithUUDI:tmpBlog.topicId];
                    [cell.btnDigitalEnterprise setTitle:[highlightedTopic.topicname uppercaseString] forState:UIControlStateNormal] ;
                    tmpBlog.isCategoryPresent=true;
                    tmpBlog.currentTopic=highlightedTopic;
                    cell.btnDigitalEnterprise.tag=indexPath.row+1000;
                    [cell.btnDigitalEnterprise addTarget:self action:@selector(redirectToCategory:) forControlEvents:UIControlEventTouchUpInside];
                }
                else{
                    for(int i=0; i<[sharedManager.topicsArray count]; i++)
                    {
                        Topics *tempTopic=(Topics *)[sharedManager.topicsArray objectAtIndex:i];
                        for (int j=0; j<[tempTopic.channelId count]; j++) {
                            if ([[tempTopic.channelId objectAtIndex:j] isEqualToString:tmpBlog.channelId]) {
                                tmpBlog.isCategoryPresent=true;
                                tmpBlog.topicId=tempTopic.topicId;
                                tmpBlog.currentTopic=tempTopic;
                                CategoryButtons *btn=[[CategoryButtons alloc] init];
                                btn.name=[NSString stringWithFormat:@"%@",tempTopic.topicname];
                                [btn setTitle:[tempTopic.topicname uppercaseString] forState:UIControlStateNormal] ;
                                [cell.btnDigitalEnterprise setTitle:[tempTopic.topicname uppercaseString] forState:UIControlStateNormal] ;
                                frame.size.width=[self widthNeededForText:[tempTopic.topicname uppercaseString] withFont:[UIFont fontWithName:@"Lato-Regular" size:12.0] height:cell.frame.size.width lineBreakMode:NSLineBreakByWordWrapping]+10;
                                [btn.titleLabel setFont: [btn.titleLabel.font fontWithSize: 12.0]];
                                [btn setTitleColor:[UIColor colorWithRed:(188.0f/255.0f) green:(182.0f/255.0f) blue:(11.0f/255.0f) alpha:1.0] forState:UIControlStateNormal  ];
                                btn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
                                btn.frame=frame;
                                cell.btnDigitalEnterprise.tag=indexPath.row+1000;
                                [cell.btnDigitalEnterprise addTarget:self action:@selector(redirectToCategory:) forControlEvents:UIControlEventTouchUpInside];
                                [btn addTarget:self action:@selector(redirectToCategory:) forControlEvents:UIControlEventTouchUpInside];
                                if (i%2==0) {
                                    xpos=xpos+frame.size.width+20;
                                    frame.origin.x=xpos;
                                }
                                else{
                                    ypos=ypos+110;
                                    frame.origin.y=ypos;
                                }
                                cell.categoryView.frame=CGRectMake(cell.categoryView.frame.origin.x, cell.categoryView.frame.origin.y, cell.categoryView.frame.size.width, ypos);
                                //[cell.categoryView addSubview:btn];
                            }
                        }
                        
                    }
                }
                if (!tmpBlog.isCategoryPresent) {
                    cell.categoryView.frame=CGRectMake(cell.categoryView.frame.origin.x, cell.categoryView.frame.origin.y, cell.categoryView.frame.size.width, 0);
                    [cell.btnDigitalEnterprise setHidden:YES];
                    
                }
                else{
                    [cell.btnDigitalEnterprise setHidden:NO];
                }
                cell.heightForCategory=heightForCategory;
                
                
            }
            else if ([[tmpDic valueForKey:@"type"] isEqualToString:@"Video"]) {
             tmpVideo=[tmpDic objectForKey:@"data"];
             [cell.videoIcon setHidden:NO];
                [cell.txtTitle setText:tmpVideo.title];
                [cell.txtDesc setText:tmpVideo.summary];
                NSString *youtubeId=[Globals extractYoutubeID:tmpVideo.videoUri];
                if (youtubeId) {
                dispatch_async(dispatch_get_main_queue(), ^{
                    //                    [cell.imgContent sd_setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat: @"http://img.youtube.com/vi/%@/1.jpg",youtubeId ] ]
                    //                                       placeholderImage:[UIImage imageNamed:@"placeholder"]];
                    
                    
                    [cell.imgContent sd_setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat: @"http://img.youtube.com/vi/%@/1.jpg",youtubeId ] ] placeholderImage:[UIImage imageNamed:@"placeholder"] options:SDWebImageRefreshCached];
                    
                });
                }
                else{
                [cell.imgContent sd_setImageWithURL:[NSURL URLWithString:tmpVideo.heroImage]
                                   placeholderImage:[UIImage imageNamed:@"placeholder"] options:SDWebImageRefreshCached];
                }
                float ypos=cell.txtDesc.frame.origin.y +  [self heightNeededForText:cell.txtDesc.text withFont:[UIFont fontWithName:@"Lato-Regular" size:12.0] width:cell.txtDesc.frame.size.width lineBreakMode:NSLineBreakByWordWrapping];
                float xpos=cell.txtDesc.frame.origin.x;
                CGRect frame=CGRectMake(5, 5, 50, 23);
                for(UIView *subview in cell.contentView.subviews)
                {
                    if([subview isKindOfClass: [CategoryButtons class]])
                    {
                        [subview removeFromSuperview];
                    }
                }
                int heightForCategory=23;
                Globals *sharedManager=[Globals sharedManager];
                tmpVideo.isCategoryPresent=false;
                if ([self getTopicWithUUDI:tmpVideo.topicId]) {
                    Topics *highlightedTopic=[self getTopicWithUUDI:tmpVideo.topicId];
                    [cell.btnDigitalEnterprise setTitle:[highlightedTopic.topicname uppercaseString] forState:UIControlStateNormal] ;
                    tmpVideo.isCategoryPresent=true;
                    tmpVideo.currentTopic=highlightedTopic;
                    cell.btnDigitalEnterprise.tag=indexPath.row+1000;
                    [cell.btnDigitalEnterprise addTarget:self action:@selector(redirectToCategory:) forControlEvents:UIControlEventTouchUpInside];
                }
                else{
                    for(int i=0; i<[sharedManager.topicsArray count]; i++)
                    {
                        Topics *tempTopic=(Topics *)[sharedManager.topicsArray objectAtIndex:i];
                        for (int j=0; j<[tempTopic.channelId count]; j++) {
                            if ([[tempTopic.channelId objectAtIndex:j] isEqualToString:tmpVideo.channelId]) {
                                tmpVideo.topicId=tempTopic.topicId;
                                tmpVideo.isCategoryPresent=true;
                                tmpVideo.currentTopic=tempTopic;
                                CategoryButtons *btn=[[CategoryButtons alloc] init];
                                btn.name=[NSString stringWithFormat:@"%@",tempTopic.topicname];
                                [btn setTitle:[tempTopic.topicname uppercaseString] forState:UIControlStateNormal] ;
                                [cell.btnDigitalEnterprise setTitle:[tempTopic.topicname uppercaseString] forState:UIControlStateNormal] ;
                                frame.size.width=[self widthNeededForText:[tempTopic.topicname uppercaseString] withFont:[UIFont fontWithName:@"Lato-Regular" size:12.0] height:cell.frame.size.width lineBreakMode:NSLineBreakByWordWrapping]+10;
                                [btn.titleLabel setFont: [btn.titleLabel.font fontWithSize: 12.0]];
                                [btn setTitleColor:[UIColor colorWithRed:(188.0f/255.0f) green:(182.0f/255.0f) blue:(11.0f/255.0f) alpha:1.0] forState:UIControlStateNormal  ];
                                cell.btnDigitalEnterprise.tag=indexPath.row+1000;
                                [cell.btnDigitalEnterprise addTarget:self action:@selector(redirectToCategory:) forControlEvents:UIControlEventTouchUpInside];
                                btn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
                                btn.frame=frame;
                                [btn addTarget:self action:@selector(redirectToCategory:) forControlEvents:UIControlEventTouchUpInside];
                                if (i%2==0) {
                                    xpos=xpos+frame.size.width+20;
                                    frame.origin.x=xpos;
                                }
                                else{
                                    ypos=ypos+110;
                                    frame.origin.y=ypos;
                                }
                                cell.categoryView.frame=CGRectMake(cell.categoryView.frame.origin.x, cell.categoryView.frame.origin.y, cell.categoryView.frame.size.width, ypos);
                                //[cell.categoryView addSubview:btn];
                            }
                        }
                        
                    }
                }
                if (!tmpVideo.isCategoryPresent) {
                    cell.categoryView.frame=CGRectMake(cell.categoryView.frame.origin.x, cell.categoryView.frame.origin.y, cell.categoryView.frame.size.width, 0);
                    [cell.btnDigitalEnterprise setHidden:YES];
                    cell.btnDigitalEnterprise.frame=CGRectMake(cell.btnDigitalEnterprise.frame.origin.x, cell.btnDigitalEnterprise.frame.origin.y, cell.btnDigitalEnterprise.frame.size.width, 0);
                }
                else{
                    [cell.btnDigitalEnterprise setHidden:NO];
                    cell.btnDigitalEnterprise.frame=CGRectMake(cell.btnDigitalEnterprise.frame.origin.x, cell.btnDigitalEnterprise.frame.origin.y, cell.btnDigitalEnterprise.frame.size.width, 20);
                }
                cell.heightForCategory=heightForCategory;
                
            }
        
       // float ypos=cell.txtDesc.frame.origin.y +   cell.txtDesc.frame.size.height;
        
    }
    
    [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
    return cell;
    
}
-(void) redirectToCategory:(id)btn{
    Globals *sharedManager;
    UIButton *tmpBtn=(UIButton *)btn;
    NSDictionary *dic;
    if (isSearch) {
        dic=[searchResults objectAtIndex:tmpBtn.tag-1000];
    }
    else{
        dic=[commonArray objectAtIndex:tmpBtn.tag-1000];
    }
    
    Topics *tempTopic;
    Articles *tempArticle;
    Blogs *tempBlog;
    Video *tempVideo;
    NSString *channelId;
    NSString *topicId;
    if ([[dic valueForKey:@"type"] isEqualToString:@"Articles"]) {
        tempArticle=(Articles *)[dic objectForKey:@"data"];
        tempTopic=tempArticle.currentTopic;
        channelId=tempArticle.channelId;
        topicId=tempArticle.topicId;
    }
    else if ([[dic valueForKey:@"type"] isEqualToString:@"Blog"]) {
        tempBlog=(Blogs *)[dic objectForKey:@"data"];
        tempTopic=tempBlog.currentTopic;
        channelId=tempBlog.channelId;
        topicId=tempBlog.topicId;
    }
    else if ([[dic valueForKey:@"type"] isEqualToString:@"Video"]) {
        tempVideo=(Video *)[dic objectForKey:@"data"];
        tempTopic=tempVideo.currentTopic;
        channelId=tempVideo.channelId;
        topicId=tempVideo.topicId;
    }
    sharedManager=[Globals sharedManager];
    
    [sharedManager showLoader];
    NSMutableArray *dashboardList=MArray;
    
    
    
    // OLD Looping for Topic
//    for (int j=0; j<[[tempTopic channelId] count]; j++) {
//        
//        NSString *channelId=[[tempTopic channelId] objectAtIndex:j];
//        
//        [sharedManager.sync getChannelsForUDIDs:@[channelId] WithCompletionblock:^(NSArray *result, NSString *str, int status) {
//            Channels *ch1=(Channels *)[result objectAtIndex:0];
//            
//            if ([[ch1 type] isEqualToString:@"Articles"]) {
//                [self getArticles:ch1.uuid];
//                for(int k=0; k<[self.articleListArray count]; k++)
//                {
//                    NSDictionary *dic=[[NSDictionary alloc] initWithObjects:@[[self.articleListArray objectAtIndex:k],@"Articles"] forKeys:@[@"data",@"type"]];
//                    [dashboardList addObject:dic];
//                }
//            }
//            else if ([[ch1 type] isEqualToString:@"Blog"]) {
//                [self getBlogs:ch1.uuid];
//                
//                
//                for(int k=0; k<[self.blogListArray count]; k++)
//                {
//                    NSDictionary *dic=[[NSDictionary alloc] initWithObjects:@[[self.blogListArray objectAtIndex:k],@"Blog"] forKeys:@[@"data",@"type"]];
//                    [dashboardList addObject:dic];
//                }
//                
//            }
//            else if ([[ch1 type] isEqualToString:@"Video"]) {
//                [self getVideos:ch1.uuid];
//                for(int k=0; k<[self.videoListArray count]; k++)
//                {
//                    NSDictionary *dic=[[NSDictionary alloc] initWithObjects:@[[self.videoListArray objectAtIndex:k],@"Video"] forKeys:@[@"data",@"type"]];
//                    [dashboardList addObject:dic];
//                }
//            }
//        }];
//        
//    }
    
    
    // Looping for Topic New Logic
    [sharedManager.sync getChannelsForUDIDs:@[channelId] WithCompletionblock:^(NSArray *result, NSString *str, int status) {
        
        if ([result count]>0) {
            
            
            Channels *ch1=(Channels *)[result objectAtIndex:0];
            
            
            
            if ([[ch1 type] isEqualToString:@"Articles"]) {
                [self getArticles:ch1.uuid];
                for(int k=0; k<[self.articleListArray count]; k++)
                {
                    
                    if ([[[self.articleListArray objectAtIndex:k] topicId] isEqualToString:topicId]) {
                        NSDictionary *dic=[[NSDictionary alloc] initWithObjects:@[[self.articleListArray objectAtIndex:k],@"Articles"] forKeys:@[@"data",@"type"]];
                        [dashboardList addObject:dic];
                    }
                    
                }
            }
            else if ([[ch1 type] isEqualToString:@"Blog"]) {
                [self getBlogs:ch1.uuid];
                
                
                for(int k=0; k<[self.blogListArray count]; k++)
                {
                    
                    if ([[[self.blogListArray objectAtIndex:k] topicId] isEqualToString:topicId]) {
                        
                        
                        NSDictionary *dic=[[NSDictionary alloc] initWithObjects:@[[self.blogListArray objectAtIndex:k],@"Blog"] forKeys:@[@"data",@"type"]];
                        [dashboardList addObject:dic];
                        
                    }
                    
                }
                
            }
            else if ([[ch1 type] isEqualToString:@"Video"]) {
                [self getVideos:ch1.uuid];
                for(int k=0; k<[self.videoListArray count]; k++)
                {
                    
                    if ([[[self.videoListArray objectAtIndex:k] topicId] isEqualToString:topicId]) {
                        NSDictionary *dic=[[NSDictionary alloc] initWithObjects:@[[self.videoListArray objectAtIndex:k],@"Video"] forKeys:@[@"data",@"type"]];
                        [dashboardList addObject:dic];
                        
                    }
                }
            }
        }
    }];
    
    UIStoryboard *story=[UIStoryboard storyboardWithName:@"Main" bundle:nil];
    ArticalListVC  *article=[story instantiateViewControllerWithIdentifier:@"ArticalListVC"];
    [[SlideNavigationController sharedInstance] toggleLeftMenu];
    article.dashboardList=[dashboardList mutableCopy];
    article.isCategory=YES;
    article.titleScreen=[tempTopic topicname];
    //[Globals pushNewViewController:article];
    DashboardVC *dashboard=(DashboardVC *)[[SlideNavigationController sharedInstance] topViewController];
    [[SlideNavigationController sharedInstance] pushViewController:article animated:NO];
    //    [UIView animateWithDuration:1.55 animations:^{
    //        dashboard.tableView.transform = CGAffineTransformMakeScale(1.5, 1.5);
    //        dashboard.tableView.alpha = 0.0;
    //        dashboard.tableView.frame=CGRectMake(dashboard.tableView.frame.origin.x, 320-dashboard.tableView.frame.origin.y, dashboard.tableView.frame.size.width, dashboard.tableView.frame.size.height);
    //    } completion:^(BOOL finished) {
    //        if (finished) {
    //            dashboard.tableView.frame=CGRectMake(dashboard.tableView.frame.origin.x, 0, dashboard.tableView.frame.size.width, dashboard.tableView.frame.size.height);
    //            dashboard.tableView.alpha = 1.0;
    //            dashboard.tableView.transform = CGAffineTransformMakeScale(1.0, 1.0);
    //            [[SlideNavigationController sharedInstance] pushViewController:article animated:NO];
    //            
    //        }
    //    }];
    
}
-(BOOL)searchBarShouldBeginEditing:(UISearchBar *)searchBar{
    [self.noData setHidden:YES];
    //tblView.frame=CGRectMake(tblView.frame.origin.x, 80, tblView.frame.size.width, tblView.frame.size.height);
    //self.searchDisplayController.searchResultsTableView.frame=CGRectMake(self.searchDisplayController.searchResultsTableView.frame.origin.x, 0, self.searchDisplayController.searchResultsTableView.frame.size.width, tblView.frame.size.height);
   // [tmpView setHidden:NO];
    //[headerView setHidden:YES];
    //[tmpView sendSubviewToBack:tblView];
    //searchBar.frame=CGRectMake(searchBar.frame.origin.x, searchBar.frame.origin.y, self.view.frame.size.width, 44);
    [tblView reloadData];
    [tblView reloadInputViews];
    [tblView setNeedsLayout];
    [tblView layoutIfNeeded];
    [tblView reloadData];
    return YES;
}

-(BOOL)searchBarShouldEndEditing:(UISearchBar *)searchBar{
    [self.noData setHidden:YES];
    [headerView setHidden:NO];
    [tmpView setHidden:YES];
    [self.searchDisplayController.searchResultsTableView reloadData];
    [self.searchDisplayController.searchResultsTableView reloadInputViews];
    [tblView reloadData];
    [tblView reloadInputViews];
    [tblView setNeedsLayout];
    [tblView layoutIfNeeded];
    [tblView reloadData];
    return YES;
}
-(void)searchDisplayController:(UISearchDisplayController *)controller didShowSearchResultsTableView:(UITableView *)tableView{
    [tableView setFrame:CGRectMake(0, 40, tblView.frame.size.width, tblView.frame.size.height)];
    
    
}
-(void)updateSearchResultsForSearchController:(UISearchController *)searchController{
    @try{
        NSString *strSearchName =searchController.searchBar.text;
        
        if ([strSearchName isEqualToString:@""] ) {
            isSearch = NO;
        }
        else {
            isSearch = YES;
//            [Articles filterArrayUsingString:strSearchName WithCompletion:^(NSArray *result, NSString *str, int status) {
//                //
//                searchResults=[result mutableCopy];
//                [tblView reloadData];
//            }] ;
            
            
            [Articles filterArrayUsingString:strSearchName WithCompletion:^(NSArray *result, NSString *str, int status) {
                //
                isSearch=true;
                
                for (int i=0; i<[result count]; i++) {
                    NSDictionary *dic=[[NSDictionary alloc] initWithObjects:@[[result objectAtIndex:i],@"Articles"] forKeys:@[@"data",@"type"]];
                    [searchResults addObject:dic];
                }
                
                
                [self.searchDisplayController.searchResultsTableView performSelectorOnMainThread:@selector(reloadData) withObject:nil waitUntilDone:YES];
                [self.searchDisplayController.searchResultsTableView reloadData];
                
                [tblView reloadData];
                [self.searchDisplayController.searchResultsTableView beginUpdates];
                [self.searchDisplayController.searchResultsTableView endUpdates];
                
            }];
            [Blogs filterArrayUsingString:strSearchName WithCompletion:^(NSArray *result, NSString *str, int status) {
                //
                isSearch=true;
                for (int i=0; i<[result count]; i++) {
                    NSDictionary *dic=[[NSDictionary alloc] initWithObjects:@[[result objectAtIndex:i],@"Blog"] forKeys:@[@"data",@"type"]];
                    [searchResults addObject:dic];
                }
                
//                if([result count]==0 && self.searchstr)
//                {
//                    [self.noData setHidden:NO];
//                }
//                else{
//                    [self.noData setHidden:YES];
//                }
                [self.searchDisplayController.searchResultsTableView performSelectorOnMainThread:@selector(reloadData) withObject:nil waitUntilDone:YES];
                [self.searchDisplayController.searchResultsTableView reloadData];
                
                [tblView reloadData];
                [self.searchDisplayController.searchResultsTableView beginUpdates];
                [self.searchDisplayController.searchResultsTableView endUpdates];
                
            }];
            [Video filterArrayUsingString:strSearchName WithCompletion:^(NSArray *result, NSString *str, int status) {
                //
                isSearch=true;
                for (int i=0; i<[result count]; i++) {
                    NSDictionary *dic=[[NSDictionary alloc] initWithObjects:@[[result objectAtIndex:i],@"Video"] forKeys:@[@"data",@"type"]];
                    [searchResults addObject:dic];
                }
                
//                if([result count]==0 && self.searchstr)
//                {
//                    [self.noData setHidden:NO];
//                }
//                else{
//                    [self.noData setHidden:YES];
//                }
                [self.searchDisplayController.searchResultsTableView performSelectorOnMainThread:@selector(reloadData) withObject:nil waitUntilDone:YES];
                [self.searchDisplayController.searchResultsTableView reloadData];
                
                [tblView reloadData];
                [self.searchDisplayController.searchResultsTableView beginUpdates];
                [self.searchDisplayController.searchResultsTableView endUpdates];
                
            }];
            [self.searchResults setText:[NSString stringWithFormat:@"%d Results",[searchResults count] ]];
            
            if([searchResults count]==0 && self.searchstr)
            {
                [self.noData setHidden:NO];
            }
            else{
                [self.noData setHidden:YES];
            }
            
        }
        //[self.tableView reloadData];
    } @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    @finally {
    }
}
-(IBAction)btnMenuClicked:(id)sender
{
    //
}
- (void)searchDisplayController:(UISearchDisplayController *)controller didLoadSearchResultsTableView:(UITableView *)tableView
{
    [self.searchDisplayController.searchResultsTableView beginUpdates];

    [self.searchDisplayController.searchResultsTableView endUpdates];
//    if ([articleListArray count] == 0) {
//        tableView.rowHeight = 110;
//    }
//    else{
//        CellArticle *cell = (CellArticle *)[tableView dequeueReusableCellWithIdentifier:@"cellArticle"];
//        Articles *tmpArticle;
//        if (!isSearch) {
//            tmpArticle=[articleListArray objectAtIndex:indexPath.row];
//        }
//        else{
//            if (searchResults > 0) {
//                tmpArticle=[searchResults objectAtIndex:indexPath.row];
//            }
//            
//        }
//        
//        [cell.txtTitle setText:tmpArticle.title];
//        [cell.txtDesc setText:tmpArticle.summary];
//        CGRect frame=cell.categoryView.frame;
//        if ([tmpArticle.meta.category count] > 2) {
//            frame.size.height=40 * ([tmpArticle.meta.category count] /2 );
//        }
//        frame.size.height=40;
//        cell.categoryView.frame=frame;
//        return [self calculaeHeightForTableViewCell:cell];
//        
//    }
    //tableView.rowHeight = 54.0f; // or some other height
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([commonArray count] == 0) {
        return 140;
    }
    else{
        CellArticle *cell = (CellArticle *)[tableView dequeueReusableCellWithIdentifier:@"cellArticle"];
        Articles *tmpArticle,*tmpBlog, *tmpVideo;
        NSDictionary *tmpDic=[[NSDictionary alloc] init];
        if (!isSearch) {
            tmpDic=[commonArray objectAtIndex:indexPath.row];
        }
        else{
            if (searchResults > 0) {
                //tmpArticle=[searchResults objectAtIndex:indexPath.row];
                tmpDic=[searchResults objectAtIndex:indexPath.row];
            }
            
        }
        if ([[tmpDic valueForKey:@"type"] isEqualToString:@"Articles"]) {
            tmpArticle=[tmpDic objectForKey:@"data"];
            [cell.txtTitle setText:tmpArticle.title];
            [cell.txtDesc setText:tmpArticle.summary];
            CGRect frame=cell.categoryView.frame;
            if ([tmpArticle.meta.category count] > 2) {
                frame.size.height=23 * ([tmpArticle.meta.category count] /2 );
            }
            frame.size.height=23;
            cell.categoryView.frame=frame;
        }
        else if ([[tmpDic valueForKey:@"type"] isEqualToString:@"Blog"]) {
            tmpBlog=[tmpDic objectForKey:@"data"];
            [cell.txtTitle setText:tmpBlog.title];
            [cell.txtDesc setText:tmpBlog.summary];
            CGRect frame=cell.categoryView.frame;
            if ([tmpBlog.meta.category count] > 2) {
                frame.size.height=23 * ([tmpBlog.meta.category count] /2 );
            }
            frame.size.height=23;
            cell.categoryView.frame=frame;
        }
        else if ([[tmpDic valueForKey:@"type"] isEqualToString:@"Video"]) {
            tmpVideo=[tmpDic objectForKey:@"data"];
            [cell.txtTitle setText:tmpVideo.title];
            [cell.txtDesc setText:tmpVideo.summary];
            CGRect frame=cell.categoryView.frame;
            if ([tmpVideo.meta.category count] > 2) {
                frame.size.height=23 * ([tmpBlog.meta.category count] /2 );
            }
            frame.size.height=23;
            cell.categoryView.frame=frame;
        }
        
       
        
        [self performSelectorOnMainThread:@selector(calculaeHeightForTableViewCell:) withObject:cell waitUntilDone:YES];
        if( tmpArticle.isCategoryPresent || tmpBlog.isCategoryPresent || tmpVideo.isCategoryPresent)
        {
            return 155;
        }
        else{
            return 140;
        }
        //return sizes;
       // return tmph+padding;
        
    }
}
-(void)calculaeHeightForTableViewCell:(CellArticle *)sizingCell{
    
    CGFloat tmpheight=[self heightNeededForText:sizingCell.txtDesc.text withFont:[UIFont fontWithName:@"Lato-Bold" size:12.0] width:sizingCell.frame.size.width lineBreakMode:NSLineBreakByWordWrapping] + [self heightNeededForText:sizingCell.txtTitle.text withFont:[UIFont fontWithName:@"Lato-Regular" size:18.0] width:sizingCell.frame.size.width lineBreakMode:NSLineBreakByWordWrapping];
    tmpheight=tmpheight + sizingCell.categoryView.frame.size.height;
    //tmpheight=tmpheight + sizingCell.categoryView.frame.size.height+15;
    CGFloat tmph=MAX(tmpheight, 140);
    
    CGSize size = CGSizeMake(sizingCell.frame.size.width, tmph);
    NSLog(@"%f",size.height);
    int padding = 20.0;
    if (isSearch) {
       sizes= size.height + padding + 30;
    }
    else{
        sizes= size.height + padding;
    }
    sizes= size.height +10;
    
}
- (CGFloat)heightNeededForText:(NSString *)text withFont:(UIFont *)font width:(CGFloat)width lineBreakMode:(NSLineBreakMode)lineBreakMode {
    NSMutableParagraphStyle * paragraphStyle = [[NSMutableParagraphStyle alloc] init];
    paragraphStyle.lineBreakMode = lineBreakMode;
    CGSize size = [text boundingRectWithSize:CGSizeMake(width, CGFLOAT_MAX)
                                     options:(NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingUsesFontLeading)
                                  attributes:@{ NSFontAttributeName: font, NSParagraphStyleAttributeName: paragraphStyle }
                                     context:nil].size;
    
    return ceilf(size.height);
}

- (CGFloat)widthNeededForText:(NSString *)text withFont:(UIFont *)font height:(CGFloat)width lineBreakMode:(NSLineBreakMode)lineBreakMode {
    NSMutableParagraphStyle * paragraphStyle = [[NSMutableParagraphStyle alloc] init];
    paragraphStyle.lineBreakMode = lineBreakMode;
    CGSize size = [text boundingRectWithSize:CGSizeMake(CGFLOAT_MAX,width )
                                     options:(NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingUsesFontLeading)
                                  attributes:@{ NSFontAttributeName: font, NSParagraphStyleAttributeName: paragraphStyle }
                                     context:nil].size;
    
    return ceilf(size.width);
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
     if ( isSearch) {
    if ([searchResults count] != 0) {
        NSDictionary *dic=[[NSDictionary alloc] init];
        dic=[searchResults objectAtIndex:indexPath.row];
        UIStoryboard *story=[UIStoryboard storyboardWithName:@"Main" bundle:nil];
        ArticleDetailVC  *article=[story instantiateViewControllerWithIdentifier:@"ArticleDetailVC"];
        if ([[dic valueForKey:@"type"] isEqualToString:@"Articles"]) {
            article.currentArticle =[dic objectForKey:@"data"];
        }
        else if ([[dic valueForKey:@"type"] isEqualToString:@"Blog"]) {
            article.currentBlog =[dic objectForKey:@"data"];
        }
        else if ([[dic valueForKey:@"type"] isEqualToString:@"Video"])
        {
            Video *currentVideo=[dic  objectForKey:@"data"];
            NSString *youtubeId=[Globals extractYoutubeID:currentVideo.videoUri];
            if (youtubeId) {
                //
                
                self.playerView=[[YTPlayerView alloc] initWithFrame:self.view.frame];
                NSDictionary *param=[[NSDictionary alloc] initWithObjects:@[@"0"] forKeys:@[@"showinfo"]];
                [self.playerView loadWithVideoId:youtubeId playerVars:param];
                //                UIViewController *playerView=[[UIViewController alloc] init];
                //                [playerView.view addSubview:video];
                [self.playerView playVideo];
                [self.view addSubview:self.playerView];
                [self.playerView setAutoresizingMask:UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight];
                self.playerView.delegate=self;
                Globals *sharedManager=[Globals sharedManager];
                [sharedManager showLoader];
                [self.playerView playVideo];
                sharedManager.isVideoPlaying=true;
                //                [self presentViewController:playerView animated:YES completion:^{
                //                    [video playVideo];
                //                }];
                
            }
            else{
                NSURL *movieURL = [NSURL URLWithString:currentVideo.videoUri];
                MPMoviePlayerViewController *movieController = [[MPMoviePlayerViewController alloc] initWithContentURL:movieURL];
                [self presentMoviePlayerViewControllerAnimated:movieController];
                [movieController.moviePlayer play];
                
            }
            return;
            //[video loadWithVideoId:youtubeId];
        }
        //[Globals pushNewViewController:article];
        Globals *sharedManager;
        sharedManager=[Globals sharedManager];
        [sharedManager showLoaderIn:self.view];
        [self.searchDisplayController setActive:NO];
        [self searchBarCancelButtonClicked:self.searchDisplayController.searchBar];
        [[SlideNavigationController sharedInstance] pushViewController:article animated:NO];
    }
         
     }
     else{
         if ([commonArray count] != 0) {
             NSDictionary *dic=[[NSDictionary alloc] init];
             dic=[commonArray objectAtIndex:indexPath.row];
             UIStoryboard *story=[UIStoryboard storyboardWithName:@"Main" bundle:nil];
             ArticleDetailVC  *article=[story instantiateViewControllerWithIdentifier:@"ArticleDetailVC"];
             if ([[dic valueForKey:@"type"] isEqualToString:@"Articles"]) {
                 article.currentArticle =[dic objectForKey:@"data"];
             }
             else if ([[dic valueForKey:@"type"] isEqualToString:@"Blog"]) {
                 article.currentBlog =[dic objectForKey:@"data"];
             }
             else if ([[dic valueForKey:@"type"] isEqualToString:@"Video"])
             {
                 Video *currentVideo=[dic  objectForKey:@"data"];
                 NSString *youtubeId=[Globals extractYoutubeID:currentVideo.videoUri];
                 if (youtubeId) {
                     //
                     
                     self.playerView=[[YTPlayerView alloc] initWithFrame:self.view.frame];
                     NSDictionary *param=[[NSDictionary alloc] initWithObjects:@[@"0"] forKeys:@[@"showinfo"]];
                     [self.playerView loadWithVideoId:youtubeId playerVars:param];
                     //                UIViewController *playerView=[[UIViewController alloc] init];
                     //                [playerView.view addSubview:video];
                     [self.playerView playVideo];
                     [self.view addSubview:self.playerView];
                     [self.playerView setAutoresizingMask:UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight];
                     self.playerView.delegate=self;
                     Globals *sharedManager=[Globals sharedManager];
                     [sharedManager showLoader];
                     [self.playerView playVideo];
                     sharedManager.isVideoPlaying=true;
                     //                [self presentViewController:playerView animated:YES completion:^{
                     //                    [video playVideo];
                     //                }];
                     
                 }
                 else{
                     NSURL *movieURL = [NSURL URLWithString:currentVideo.videoUri];
                     MPMoviePlayerViewController *movieController = [[MPMoviePlayerViewController alloc] initWithContentURL:movieURL];
                     [self presentMoviePlayerViewControllerAnimated:movieController];
                     [movieController.moviePlayer play];
                     
                 }
                 return;
                 //[video loadWithVideoId:youtubeId];
             }
             //[Globals pushNewViewController:article];
             Globals *sharedManager;
             sharedManager=[Globals sharedManager];
             [sharedManager showLoaderIn:self.view];
             [self.searchDisplayController setActive:NO];
             [self searchBarCancelButtonClicked:self.searchDisplayController.searchBar];
             [[SlideNavigationController sharedInstance] pushViewController:article animated:NO];
         }
     }
}
- (void)hideSearchBar {
    tblView.contentOffset = CGPointMake(0, 64);
}
-(BOOL)searchDisplayController:(UISearchDisplayController *)controller shouldReloadTableForSearchString:(NSString *)searchString
{

    [self filterContentForSearchText:searchString
                               scope:[[self.searchDisplayController.searchBar scopeButtonTitles]
                                      objectAtIndex:[self.searchDisplayController.searchBar
                                                     selectedScopeButtonIndex]]];
    [self.searchDisplayController.searchResultsTableView reloadInputViews];
    [self.searchDisplayController.searchResultsTableView reloadData];
    [tblView reloadData];
    // [controller.searchResultsTableView setFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height)];
    //[controller.searchContentsController.view setFrame:CGRectMake(controller.searchContentsController.view.frame.origin.x, controller.searchContentsController.view.frame.origin.y, self.view.frame.size.width, self.view.frame.size.height+50)];
    return YES;
}

// For Searchbar search function
- (void)filterContentForSearchText:(NSString*)searchText scope:(NSString*)scope
{
    if(![searchText isEqualToString:@""])
    {
        searchResults=MArray;
        [Articles filterArrayUsingString:searchText WithCompletion:^(NSArray *result, NSString *str, int status) {
            //
            isSearch=true;
            
            for (int i=0; i<[result count]; i++) {
                NSDictionary *dic=[[NSDictionary alloc] initWithObjects:@[[result objectAtIndex:i],@"Articles"] forKeys:@[@"data",@"type"]];
                [searchResults addObject:dic];
            }
            
//            if([result count]==0 && self.searchstr)
//            {
//                [self.noData setHidden:NO];
//            }
//            else{
//                [self.noData setHidden:YES];
//            }
            [self.searchDisplayController.searchResultsTableView performSelectorOnMainThread:@selector(reloadData) withObject:nil waitUntilDone:YES];
            [self.searchDisplayController.searchResultsTableView reloadData];

            [tblView reloadData];
            [self.searchDisplayController.searchResultsTableView beginUpdates];
            [self.searchDisplayController.searchResultsTableView endUpdates];
            
        }];
        [Blogs filterArrayUsingString:searchText WithCompletion:^(NSArray *result, NSString *str, int status) {
            //
            isSearch=true;
            for (int i=0; i<[result count]; i++) {
                NSDictionary *dic=[[NSDictionary alloc] initWithObjects:@[[result objectAtIndex:i],@"Blog"] forKeys:@[@"data",@"type"]];
                [searchResults addObject:dic];
            }
            
//            if([result count]==0 && self.searchstr)
//            {
//                [self.noData setHidden:NO];
//            }
//            else{
//                [self.noData setHidden:YES];
//            }
            [self.searchDisplayController.searchResultsTableView performSelectorOnMainThread:@selector(reloadData) withObject:nil waitUntilDone:YES];
            [self.searchDisplayController.searchResultsTableView reloadData];
            
            [tblView reloadData];
            [self.searchDisplayController.searchResultsTableView beginUpdates];
            [self.searchDisplayController.searchResultsTableView endUpdates];
            
        }];
        [Video filterArrayUsingString:searchText WithCompletion:^(NSArray *result, NSString *str, int status) {
            //
            isSearch=true;
            for (int i=0; i<[result count]; i++) {
                NSDictionary *dic=[[NSDictionary alloc] initWithObjects:@[[result objectAtIndex:i],@"Video"] forKeys:@[@"data",@"type"]];
                [searchResults addObject:dic];
            }
            
//            if([result count]==0 && self.searchstr)
//            {
//                [self.noData setHidden:NO];
//            }
//            else{
//                [self.noData setHidden:YES];
//            }
            [self.searchDisplayController.searchResultsTableView performSelectorOnMainThread:@selector(reloadData) withObject:nil waitUntilDone:YES];
            [self.searchDisplayController.searchResultsTableView reloadData];
            
            [tblView reloadData];
            [self.searchDisplayController.searchResultsTableView beginUpdates];
            [self.searchDisplayController.searchResultsTableView endUpdates];
            
        }];
        
        if([searchResults count]==0 && self.searchstr)
        {
            [self.noData setHidden:NO];
        }
        else{
            [self.noData setHidden:YES];
        }
    }
    else{
        isSearch=false;
        [tblView reloadData];
        [tblView reloadInputViews];
    }
    
    // searchResults = [recipes filteredArrayUsingPredicate:resultPredicate];
}


-(void)searchBarCancelButtonClicked:(UISearchBar *)searchBar
{
    isSearch=false;
    [self.noData setHidden:YES];
    [tblView reloadData];
    
}
-(void)viewWillDisappear:(BOOL)animated
{
    [searchBar setText:self.searchstr];

    [super viewWillDisappear:YES];
    [[UIApplication sharedApplication] setStatusBarHidden:NO];
    
}
-(void)playerView:(YTPlayerView *)playerView didChangeToState:(YTPlayerState)state
{
    if (state==kYTPlayerStateEnded) {
        [playerView removeFromSuperview];
        Globals *sharedManager=[Globals sharedManager];
        [sharedManager hideLoader];
        sharedManager.isVideoPlaying=false;
        NSNumber *value = [NSNumber numberWithInt:UIInterfaceOrientationPortrait];
        [[UIDevice currentDevice] setValue:value forKey:@"orientation"];
    }
}
-(UIColor *)playerViewPreferredWebViewBackgroundColor:(YTPlayerView *)playerView
{
    return [UIColor blackColor];
}
-(void)playerViewDidBecomeReady:(YTPlayerView *)playerView{
    Globals *sharedManager=[Globals sharedManager];
    [sharedManager hideLoader];
}

-(void)playerView:(YTPlayerView *)playerView receivedError:(YTPlayerError)error
{
    Globals *sharedManager=[Globals sharedManager];
    [sharedManager hideLoader];
    sharedManager.isVideoPlaying=false;
    NSNumber *value = [NSNumber numberWithInt:UIInterfaceOrientationPortrait];
    [[UIDevice currentDevice] setValue:value forKey:@"orientation"];
}

// For animation in UITableView Cell
-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath{
    
//    if (canAnimate && indexPath.row!=0) {
//        CATransition *transition = [CATransition animation];
//        transition.duration = 0.9;
//        transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseIn];
//        transition.type = kCATransitionMoveIn;
//        transition.subtype = kCATransitionFromTop;
//        [cell.layer addAnimation:transition forKey:kCATransition];
//        
//        //2. Define the initial state (Before the animation)
//        cell.layer.shadowColor = [[UIColor blackColor]CGColor];
//        cell.layer.shadowOffset = CGSizeMake(10, 10);
//        cell.alpha = 0.9;
//        
//        //cell.layer.transform = rotation;
//        //cell.layer.anchorPoint = CGPointMake(0, 0.5);
//        
//        
//        //3. Define the final state (After the animation) and commit the animation
//        [UIView beginAnimations:@"fade" context:NULL];
//        [UIView setAnimationDuration:1.8];
//        cell.layer.transform = CATransform3DIdentity;
//        cell.alpha = 1;
//        cell.layer.shadowOffset = CGSizeMake(0, 0);
//        [UIView commitAnimations];
//    }
//    
//    if (indexPath.row==([commonArray count] -1)) {
//        canAnimate=false;
//    }
    if ([cell respondsToSelector:@selector(setSeparatorInset:)]) {
        [cell setSeparatorInset:UIEdgeInsetsZero];
    }
    
    if ([cell respondsToSelector:@selector(setLayoutMargins:)]) {
        [cell setLayoutMargins:UIEdgeInsetsZero];
    }
}

-(void) getArticles:(NSString *)channelId{
    Globals *sharedManager;
    sharedManager=[Globals sharedManager];
    // Checking if We have channels or already set uuid of topics
    
    // Initializing Variables
    self.articleListArray=[[NSMutableArray alloc] init];
    
    // Getting List of Articles for particular channels
    [sharedManager.sync getArticlesForChannel:channelId WithCompletionBlock:^(id result,NSString *str, int status) {
        self.articleListArray=[result mutableCopy];
    }];
    
}
-(void)getVideos:(NSString *)channelId{
    Globals *sharedManager;
    sharedManager=[Globals sharedManager];
    // Checking if We have channels or already set uuid of topics
    
    // Initializing Variables
    self.videoListArray=[[NSMutableArray alloc] init];
    
    // Getting List of Articles for particular channels
    [sharedManager.sync getVideosForChannel:channelId WithCompletionBlock:^(id result,NSString *str, int status) {
        self.videoListArray=[result mutableCopy];
        [sharedManager hideLoader];
    }];
    
}
-(void) getBlogs:(NSString *)channelId{
    Globals *sharedManager;
    sharedManager=[Globals sharedManager];
    // Checking if We have channels or already set uuid of topics
    
    // Initializing Variables
    self.blogListArray=[[NSMutableArray alloc] init];
    
    // Getting List of Articles for particular channels
    
    [sharedManager.sync getBlogsForChannel:channelId WithCompletionBlock:^(id result,NSString *str, int status) {
        self.blogListArray=[result mutableCopy];
    }];
}
-(void)viewDidLayoutSubviews
{
    if ([tblView respondsToSelector:@selector(setSeparatorInset:)]) {
        [tblView setSeparatorInset:UIEdgeInsetsZero];
    }
    
    if ([tblView respondsToSelector:@selector(setLayoutMargins:)]) {
        [tblView setLayoutMargins:UIEdgeInsetsZero];
    }
}

-(Topics *) getTopicWithUUDI:(NSString *)topicId{
    Globals *sharedManager=[Globals sharedManager];
    for(int i=0; i<[sharedManager.topicsArray count]; i++)
    {
        if ([[[sharedManager.topicsArray objectAtIndex:i] uuid] isEqualToString:topicId]) {
            return [sharedManager.topicsArray objectAtIndex:i];
        }
    }
    return nil;
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
