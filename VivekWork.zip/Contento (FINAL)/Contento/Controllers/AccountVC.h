//
//  AccountVC.h
//  Contento
//
//  Created by aadil on 16/12/15.
//  Copyright © 2015 Zaptech. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Constants.h"
@interface AccountVC : UIViewController
@property IBOutlet UITextField *txtFirstName,*txtCompany, *txtEmail, *txtPassword;
@property IBOutlet UIButton *btnDone;
@end
