//
//  relatedArticleCell.m
//  Contento
//
//  Created by aadil on 19/11/15.
//  Copyright © 2015 Zaptech. All rights reserved.
//

#import "relatedArticleCell.h"

@implementation relatedArticleCell

@end
