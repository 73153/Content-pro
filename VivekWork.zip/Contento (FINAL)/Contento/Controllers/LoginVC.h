//
//  LoginVC.h
//  Contento
//
//  Created by Aadil on 29/10/15.
//  Copyright © 2015 Zaptech. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "IQKeyboardManager.h"
#import "AppDelegate.h"
@class AppDelegate;
@interface LoginVC : UIViewController <UITextFieldDelegate>
@property  AppDelegate *app;
@property (strong, nonatomic) IBOutlet UITextField *txtEmail;
@property (strong, nonatomic) IBOutlet UITextField *txtPassword;
- (IBAction)onBtnSignUpTapped:(id)sender;
-(IBAction)linkedInLogin:(id)sender;
- (IBAction)onBtnForgotPasswordTapped:(id)sender;
@end
