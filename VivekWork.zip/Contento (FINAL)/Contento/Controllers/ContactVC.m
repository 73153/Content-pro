//
//  ContactVC.m
//  Contento
//
//  Created by aadil on 15/12/15.
//  Copyright © 2015 Zaptech. All rights reserved.
//

#import "ContactVC.h"

@interface ContactVC ()

@end

@implementation ContactVC

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.titleLabel setText:self.title];
    [self initVC];
    [self.headerView setBackgroundColor:THEME_BG_COLOR];
    [self.doneButton setBackgroundColor:THEME_BG_COLOR];
    // Do any additional setup after loading the view.
}
-(void) initVC{
    self.sectionArray = [[NSMutableArray alloc] initWithObjects:@"From",@"Reason for contacting Contento",@"Message", nil];
    self.textFieldArray=[[NSMutableArray alloc] initWithObjects:@"Name",@"Email",@"Company",  nil];
    self.textViewArray=[[NSMutableArray alloc] initWithObjects:@"Comment", nil];
    NSArray *pickerArray=[[NSArray alloc] initWithObjects:@"Media Query or Conferences",@"Publication Request",@"Client-Server Inquiry",@"Other", nil];
    
    self.pickerArray=[[NSMutableArray alloc] initWithObjects:pickerArray, nil];
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return [self.sectionArray count];
}
-(NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    return [self.sectionArray objectAtIndex:section];
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (section==0) {
        return [self.textFieldArray count];
    }
    else if (section==1) {
        return [self.textViewArray count];
    }
    else if (section==2) {
        return [self.pickerArray count];
    }
    else{
        return 0;
    }
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if (indexPath.section==0) {
        //
        CellTextField *cell=[tableView dequeueReusableCellWithIdentifier:@"textFieldCell"];
        if(cell == nil)
        {
            cell = (CellTextField *) [[CellTextField alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"textFieldCell"];
            
        }

        [cell.inputField setPlaceholder:[self.textFieldArray objectAtIndex:indexPath.row]];
        cell.inputField.tag=(indexPath.row+11) + ((indexPath.row+11)*100);
        return cell;
    }
    else if (indexPath.section==2) {
        //
        CellTextView *cell=[tableView dequeueReusableCellWithIdentifier:@"textViewCell"];
        if(cell == nil)
        {
            cell = (CellTextView *) [[CellTextView alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"textViewCell"];
            
        }
        cell.inputField.delegate=self;
        cell.inputField.tag=10011;
        return cell;
    }
    else if (indexPath.section==1) {
        //
        CellPickerView *cell=[tableView dequeueReusableCellWithIdentifier:@"pickerViewCell"];
        if(cell == nil)
        {
            cell = (CellPickerView *) [[CellPickerView alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"pickerViewCell"];
            
        }
        cell.pickerView.tag=20022;
        cell.pickerView.delegate=self;
        return cell;
    }
    else{
        return [[UITableViewCell alloc] init];
    }
    
}

-(NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
    return [[self.pickerArray objectAtIndex:0] count];
}
-(NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component{
    return [[self.pickerArray  objectAtIndex:0] objectAtIndex:row];
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section==0) {
        return 44.0;
    }
    else if(indexPath.section==1){
        return 128.0;
    }
    else if(indexPath.section==2){
        return 165.0;
    }
    else{
        return 44.0;
    }
}
-(IBAction)btndone:(id)sender{
    BOOL isValid=true;
    NSString *name, *email,*company,*subject,*message;
    for (int i=0; i<[self.textFieldArray count]; i++) {
        UITextField *temptextField=(UITextField *)[self.view viewWithTag:((i+11) + ((i+11)*100))];
        if(i==1){
            
            if (![Validations isValidEmail:temptextField.text ] && ![Validations checkMinLength:temptextField.text withLimit:4]) {
                [Globals ShowAlertWithTitle:@"Error" Message:[NSString stringWithFormat:@"Please enter valid %@",[self.textFieldArray objectAtIndex:i]]];
                isValid=false;
                NSIndexPath *indexPath=[NSIndexPath indexPathForRow:i inSection:0];
                CellTextField *cell1=[self.tableView cellForRowAtIndexPath:indexPath];
                [cell1.img setImage:[UIImage imageNamed:@"btnuncheck"]  ];
                
            }
            else{
                NSIndexPath *indexPath=[NSIndexPath indexPathForRow:i inSection:0];
                CellTextField *cell1=[self.tableView cellForRowAtIndexPath:indexPath];
                [cell1.img setImage:[UIImage imageNamed:@"btncheck"]  ];
                email=temptextField.text;
            }
        }
        else if (![Validations isValidUnicodeName:temptextField.text ] && ![Validations checkMinLength:temptextField.text withLimit:4] && isValid) {
            [Globals ShowAlertWithTitle:@"Error" Message:[NSString stringWithFormat:@"Please enter valid %@",[self.textFieldArray objectAtIndex:i]]];
            isValid=false;
            NSIndexPath *indexPath=[NSIndexPath indexPathForRow:i inSection:0];
            CellTextField *cell1=[self.tableView cellForRowAtIndexPath:indexPath];
            [cell1.img setImage:[UIImage imageNamed:@"btnuncheck"]  ];
            
        }
        
        else if (!isValid){
            NSIndexPath *indexPath=[NSIndexPath indexPathForRow:i inSection:0];
            CellTextField *cell1=[self.tableView cellForRowAtIndexPath:indexPath];
            [cell1.img setImage:[UIImage imageNamed:@"btnuncheck"]  ];
        }
        else{
            NSIndexPath *indexPath=[NSIndexPath indexPathForRow:i inSection:0];
            CellTextField *cell1=[self.tableView cellForRowAtIndexPath:indexPath];
            [cell1.img setImage:[UIImage imageNamed:@"btncheck"]  ];
            if (i==0) {
                name=temptextField.text;
            }
            if (i==2) {
                company=temptextField.text;
            }
        }
    }
    UITextView *tempTextView=(UITextView *)[self.view viewWithTag:10011];
    tempTextView.delegate=self;
    
    if(!isValid){
        [self dismissViewControllerAnimated:YES completion:^{
            //
        }];
        return;
    }
    if (![Validations checkMinLength:tempTextView.text withLimit:10  ]) {
        [Globals ShowAlertWithTitle:@"Error" Message:[NSString stringWithFormat:@"Please enter valid %@",[self.textViewArray objectAtIndex:0]]];
        isValid=false;
    }
    UIPickerView *tempPickerView=(UIPickerView *)[self.view viewWithTag:20022];
    subject=[[self.pickerArray  objectAtIndex:0] objectAtIndex:[tempPickerView selectedRowInComponent:0]];
    if (isValid) {
        //
        Globals *sharedManager=[Globals sharedManager];
        UITextView *tempTextView=[self.textViewArray objectAtIndex:0];
        CellTextView *cell1=(CellTextView *)[self.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForItem:0 inSection:2]];
        message=cell1.inputField.text;
        
       // message=[NSString stringWithFormat:@"%@",tempTextView.text ];
 
        NSMutableDictionary *dic=[[NSMutableDictionary alloc] initWithObjects:@[message,subject,name,email,company] forKeys:@[@"message",@"subject",@"name",@"email",@"company"]];
//        NSDictionary *dic=[NSDictionary dictionaryWithObject:@[message,subject,name,email,company] forKey:@[@"message",@"subject",@"name",@"email",@"company"]];
        [APICall callPostWebService:API_CONTACT_US andDictionary:dic withToken:sharedManager.user.token completion:^(NSMutableDictionary *result, NSError *error, long code) {
            //
            if ([[result valueForKey:@"success"] boolValue]) {
                //Success
                NSLog(@"%@",result);
                [self dismissViewControllerAnimated:YES completion:^{
                    //
                }];
                
            }
            else{
                //Error
                [Globals ShowAlertWithTitle:@"Error" Message:@"Could not send your message. Try again later"];
            }
        }];
        NSLog(@"Valid");
    }
    
}
-(void)textViewDidChange:(UITextView *)textView{
    int count=[textView.text length];
    int total=500;
    if (count<total) {
        
    }
    [self.sectionArray setObject:[NSString stringWithFormat: @"Message %d/%d",count,total] atIndexedSubscript:2];
//    NSRange range = NSMakeRange(0, 2);
//    NSIndexSet *section = [NSIndexSet indexSetWithIndexesInRange:range];
//    [self.tableView reloadSections:section withRowAnimation:UITableViewRowAnimationNone];
//    [self.tableView reloadData];
    [self.tableView beginUpdates];
    CGRect frame=[self.tableView headerViewForSection:2].textLabel.frame;
    [self.tableView headerViewForSection:2].textLabel.frame=CGRectMake(frame.origin.x, frame.origin.y, self.view.frame.size.width, frame.size.height);
    [self.tableView headerViewForSection:2].textLabel.text = [NSString stringWithFormat: @"Message %d/%d",count,total];
    [self.tableView endUpdates];
   
}
-(BOOL)textViewShouldBeginEditing:(UITextView *)textView{
    if ([textView.text length] < 5000) {
        return true;
    }
    else{
        return false;
    }
}
-(void)textViewDidBeginEditing:(UITextView *)textView{
    if ([textView.text isEqualToString:@"Your Comments"]) {
        textView.text=@"";
    }
}
-(void)textViewDidEndEditing:(UITextView *)textView{
    if ([textView.text isEqualToString:@""]) {
        textView.text=@"Your Comments";
    }
    //[self.tableView reloadData];
}
-(IBAction)btnclose:(id)sender{
    [self dismissViewControllerAnimated:YES completion:^{
        //
    }];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
