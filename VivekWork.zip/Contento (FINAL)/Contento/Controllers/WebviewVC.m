//
//  WebviewVC.m
//  Contento
//
//  Created by aadil on 14/12/15.
//  Copyright © 2015 Zaptech. All rights reserved.
//

#import "WebviewVC.h"

@interface WebviewVC ()

@end

@implementation WebviewVC
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [self.titleLabel setText:self.title];
    [self.webView loadRequest:[[NSURLRequest alloc] initWithURL:[[NSURL alloc] initWithString:self.url]]];
    Globals *sharedManager;
    sharedManager=[Globals sharedManager];
    [sharedManager showLoader];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}
-(void)webViewDidFinishLoad:(UIWebView *)webView{
    Globals *sharedManager;
    sharedManager=[Globals sharedManager];
    [sharedManager hideLoader];
}
-(IBAction)btnclose:(id)sender{
    [self  dismissViewControllerAnimated:YES completion:^{
        //
    }];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
