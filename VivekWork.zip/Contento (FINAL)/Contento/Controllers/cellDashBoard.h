//
//  cellDashBoard.h
//  Contento
//
//  Created by aakil on 10/30/15.
//  Copyright © 2015 Zaptech. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface cellDashBoard : UITableViewCell

@end
