//
//  CellTextField.m
//  Contento
//
//  Created by aadil on 15/12/15.
//  Copyright © 2015 Zaptech. All rights reserved.
//

#import "CellTextField.h"

@implementation CellTextField

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
