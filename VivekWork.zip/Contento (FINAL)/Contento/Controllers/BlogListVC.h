//
//  BlogListVC.h
//  Contento
//
//  Created by aadil on 04/02/16.
//  Copyright © 2016 Zaptech. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ContentoVC.h"
#import "CellArticle.h"
#import "Validations.h"
#import "AppDelegate.h"
#import "Blogs.h"
#import <SDWebImage/UIImageView+WebCache.h>
#import "CategoryButtons.h"
#import "Constants.h"
@interface BlogListVC : UIViewController<UITableViewDataSource,UITableViewDelegate>{
    UIRefreshControl *refreshControl;
}
@property IBOutlet UIButton *btnMenu;
@property IBOutlet UITableView *tableView;
@property NSMutableArray *blogListArray;
@property Channels *currentChannel;
@property (nonatomic,strong) NSString *titleScreen;
@property IBOutlet UILabel *titleLabel, *totalBlogs;
@property BOOL isCategory,isChannel,canAnimate;
@property NSString *channelid;
@end
