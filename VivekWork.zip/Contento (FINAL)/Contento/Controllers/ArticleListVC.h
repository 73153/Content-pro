//
//  ArticleListVC.h
//  Contento
//
//  Created by aadil on 16/11/15.
//  Copyright © 2015 Zaptech. All rights reserved.
//

#import "Articles.h"
#import <UIKit/UIKit.h>
#import "Constants.h"
#import "AppDelegate.h"
@interface ArticleListVC:UIViewController <UITableViewDelegate,UITableViewDataSource>{
    
}

@end
