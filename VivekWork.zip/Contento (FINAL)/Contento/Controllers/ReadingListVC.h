//
//  ReadingListVC.h
//  Contento
//
//  Created by aadil on 03/11/15.
//  Copyright © 2015 Zaptech. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Constants.h"
@interface ReadingListVC : ContentoVC <UITableViewDataSource, UITableViewDelegate >
@property IBOutlet UITableView *tableView;
@end
