//
//  LoginVC.m
//  Contento
//
//  Created by Aadil on 29/10/15.
//  Copyright © 2015 Zaptech. All rights reserved.
//

#import "LoginVC.h"
#import "SignupVC.h"
#import "AppDelegate.h"
#import <SlideNavigationController.h>
#import "Constants.h"
#import "DashboardVC.h"
#import "IQUIView+IQKeyboardToolbar.h"
#import "SocialLogin.h"
#import "ForgotPasswordVC.h"

@implementation LoginVC
-(void)viewDidLoad{
    [super viewDidLoad];

    [self.view setBackgroundColor:THEME_BG_COLOR];

    Globals *sharedManager;
    sharedManager=[Globals sharedManager];
    
    NSString *tempLinkedIn = [[NSUserDefaults standardUserDefaults] objectForKey:@"IsLinkedInLogin"];
    if ([tempLinkedIn isEqualToString:@"true"]){
        [self isAlreadyLinkedInLogin];
        return;
    }
    
    if (([[NSUserDefaults standardUserDefaults] objectForKey:@"email"] && [[NSUserDefaults standardUserDefaults] objectForKey:@"password"]) || ([[NSUserDefaults standardUserDefaults] objectForKey:@"IsLinkedInLogin"])) {
        //
        [self.txtEmail setText:[[NSUserDefaults standardUserDefaults] objectForKey:@"email"]];
        [self.txtPassword setText:[[NSUserDefaults standardUserDefaults] objectForKey:@"password"]];
        [self onBtnLoginTapped:[UIButton new]];
    }
    [self.txtEmail setDelegate:self];
    [self.txtPassword setDelegate:self];
    [self.txtPassword addDoneOnKeyboardWithTarget:self action:@selector(onBtnLoginTapped:)];
    //[self.txtEmail setText:@"pete@tomorrow-people.com"];
    
    //[self.txtPassword setText:@"password"];
    //    [self.txtEmail setText:@"vivek2061990@gmail.com"];
    //
    //    [self.txtPassword setText:@"password"];
    //    [self.txtEmail setText:@"ashish.p@zaptechsolutions.com"];
    //    [self.txtPassword setText:@"password"];
    // [Globals ShowAlertWithTitle:@"Does not Exists" Message:@"In login list"];
    // [self.txtPassword setText:@"12345678"];
}
- (IBAction)onBtnSignUpTapped:(id)sender  {
    [self.view endEditing:YES];
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:
                                @"Main" bundle:nil];
    SignupVC *second=(SignupVC *)[storyboard instantiateViewControllerWithIdentifier:@"SignupVC"];
    [[SlideNavigationController sharedInstance] pushViewController:second animated:YES];
}

- (IBAction)onBtnForgotPasswordTapped:(id)sender  {
    [self.view endEditing:YES];
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:
                                @"Main" bundle:nil];
    ForgotPasswordVC *second=(ForgotPasswordVC *)[storyboard instantiateViewControllerWithIdentifier:@"ForgotPasswordVC"];
    [[SlideNavigationController sharedInstance] pushViewController:second animated:YES];
}



- (IBAction)onBtnLoginTapped:(id)sender  {
    [self.view endEditing:YES];
    BOOL isValid=true;
    
    /********** Temporary code to Login ***************
     UIStoryboard *storyboard = [UIStoryboard storyboardWithName:
     @"Main" bundle:nil];
     DashboardVC *second=(DashboardVC *)[storyboard instantiateViewControllerWithIdentifier:@"DashboardVC"];
     [[SlideNavigationController sharedInstance] pushViewController:second animated:YES];
     /********** Temporary code to Login ****************/
    
    if(![Validations checkMinLength:self.txtEmail.text withLimit:3 ] || ![Validations isValidEmail:self.txtEmail.text ]  )
    {
        isValid=false;
        [Globals ShowAlertWithTitle:@"Error" Message:ERROR_EMAIL];
    }
    else if(![Validations checkMinLength:self.txtPassword.text withLimit:6 ] )
    {
        isValid=false;
        [Globals ShowAlertWithTitle:@"Error" Message:ERROR_PASSWORD];
    }
    if (isValid) {
        if([Validations isconnectedToInternet])
        {
            Globals *sharedManager;
            sharedManager=[Globals sharedManager];
            sharedManager.user.email=[self.txtEmail.text mutableCopy];
            [[NSUserDefaults standardUserDefaults] setObject:self.txtEmail.text forKey:@"email"];
            [[NSUserDefaults standardUserDefaults] setObject:self.txtPassword.text forKey:@"password"];
            [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"IsLinkedInLogin"];
            
            AppDelegate *app=[[UIApplication sharedApplication] delegate];
            if(![[NSUserDefaults standardUserDefaults] objectForKey:@"deviceToken"])
            {
                [[NSUserDefaults standardUserDefaults] setObject:app.deviceTokens forKey:@"deviceToken"];
            }
            [[NSUserDefaults standardUserDefaults] synchronize];
            sharedManager.user.password=[self.txtPassword.text mutableCopy];
            [sharedManager showLoader];
            [sharedManager.user authenticate:^(NSString *str, int status){
                
                if(status==1)
                {
                    [sharedManager.user loginUser:^(NSString *str, int status){
                        
                        if(status==1){
                            
                            UIStoryboard *storyboard = [UIStoryboard storyboardWithName:
                                                        @"Main" bundle:nil];
                            DashboardVC *second=(DashboardVC *)[storyboard instantiateViewControllerWithIdentifier:@"DashboardVC"];
                            [[SlideNavigationController sharedInstance] pushViewController:second animated:YES];
                        }
                        else{
                            [sharedManager hideLoader];
                            [Globals ShowAlertWithTitle:@"Error" Message:str];
                        }
                    }];
                }
                else{
                    [sharedManager hideLoader];
                    [Globals ShowAlertWithTitle:@"Error" Message:str ];
                }
            }];
        }
        else{
            
            [Globals ShowAlertWithTitle:@"Error" Message:ERROR_INTERNET];
        }
        
    }
    
    //    [self.navigationController pushViewController:second animated:YES];
}
-(void)viewDidAppear:(BOOL)animated{
    [[IQKeyboardManager sharedManager] setEnable:NO];
}
-(void)viewDidDisappear:(BOOL)animated{
    [[IQKeyboardManager sharedManager] setEnable:YES];
}
-(void)textFieldDidBeginEditing:(UITextField *)textField{
    if (textField==self.txtEmail) {
        [self.view setFrame:CGRectMake(self.view.frame.origin.x, -50, self.view.frame.size.width, self.view.frame.size.height)];
    }
    if (textField==self.txtPassword) {
        [self.view setFrame:CGRectMake(self.view.frame.origin.x, -50, self.view.frame.size.width, self.view.frame.size.height)];
    }
}
-(BOOL)textFieldShouldEndEditing:(UITextField *)textField{
    [self.view setFrame:CGRectMake(self.view.frame.origin.x, 0, self.view.frame.size.width, self.view.frame.size.height)];
    return YES;
}
- (void)didReceiveMemoryWarning
{
    NSLog(@"Bhushan");
    [super didReceiveMemoryWarning];
    
    if([self isViewLoaded] && self.view.window == nil)
    {
        self.view = nil;
    }
}



//Pradip changes
#pragma LinkedInSignUp


-(IBAction)linkedInLogin:(id)sender{
    self.app=[[UIApplication sharedApplication] delegate];
    self.app.social=[[SocialLogin alloc] initWithSocialType:socialTypeLinkedInn];
    Globals *sharedManager;
    sharedManager=[Globals sharedManager];
    
    if(self.app.social.socialType == socialTypeLinkedInn)
    {
        
        [self.app.social loginWithLinkedInn:^(id result, NSError *error, NSString *msg, int status)
         {
             if(status == 1)
             {
                 if([Validations isconnectedToInternet])
                 {
                     [sharedManager.user authenticate:^(NSString *str, int status){
                         [sharedManager showLoader];
                         if(sharedManager.user==nil)
                         {
                             sharedManager.user = [[Users alloc] init];
                         }
                         sharedManager.linkedToken = [result valueForKey:@"id"];
                         sharedManager.user.firstName=[result valueForKey:@"firstName"];
                         sharedManager.user.lastName=[result valueForKey:@"lastName"];
                         sharedManager.user.company=[@"" mutableCopy];
                         sharedManager.user.website=[@"" mutableCopy];
                         sharedManager.user.email= [result valueForKey:@"emailAddress"];
                         sharedManager.user.jobtitle=[@"" mutableCopy];
                         sharedManager.user.phonenumber=[@"" mutableCopy];
                         sharedManager.user.password=[@"" mutableCopy];
                         [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"email"];
                         [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"password"];
                         
                         [[NSUserDefaults standardUserDefaults] setObject:sharedManager.user.firstName forKey:@"userFirstName"];
                         [[NSUserDefaults standardUserDefaults] setObject:sharedManager.user.lastName forKey:@"userLastName"];
                         
                         
                         [[NSUserDefaults standardUserDefaults] setObject:@"true" forKey:@"IsLinkedInLogin"];

                         [[NSUserDefaults standardUserDefaults] synchronize];
                         [[NSUserDefaults standardUserDefaults] synchronize];
                         
                         
                         
                         [sharedManager.user oauth:^(NSString *str, int status){
                             if(status==1)
                             {
                                 UIStoryboard *storyboard = [UIStoryboard storyboardWithName:
                                                             @"Main" bundle:nil];
                                 DashboardVC *second=(DashboardVC *)[storyboard instantiateViewControllerWithIdentifier:@"DashboardVC"];
                                 [[SlideNavigationController sharedInstance] pushViewController:second animated:YES];
                             }
                             else{
                                 [sharedManager showLoaderIn:self.view];
                                 [sharedManager.user registerUserWithoauthResponse:^(NSString *str, int status){
                                     if(status==1){
                                         NSLog(@"Thanks for registering. An email has been sent to you to verify your details.");
                                         [sharedManager hideLoader];
                                         
                                         [sharedManager.user oauth:^(NSString *str, int status){
                                             if(status==1)
                                             {
                                                 UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
                                                 DashboardVC *second=(DashboardVC *)[storyboard instantiateViewControllerWithIdentifier:@"DashboardVC"];
                                                 [[SlideNavigationController sharedInstance] pushViewController:second animated:YES];
                                             }
                                             else
                                             {
                                                 [sharedManager hideLoader];
                                                 [Globals ShowAlertWithTitle:@"Error" Message:str];
                                             }
                                         }];
                                     }
                                     else
                                     {
                                         [sharedManager hideLoader];
                                         [Globals ShowAlertWithTitle:@"Error" Message:str];
                                     }
                                 }];
                             }
                         }]; }];
                 }
                 else{
                     
                     [Globals ShowAlertWithTitle:@"Error" Message:ERROR_INTERNET];
                 }
                 
                 NSLog(@"%@",msg);
             }
             else{
                 [Globals ShowAlertWithTitle:@"Error" Message:@"Could not connect to LinkedIn"];
             }
         }];
        
    }
}
-(void)isAlreadyLinkedInLogin{
    
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:
                                @"Main" bundle:nil];
    DashboardVC *second=(DashboardVC *)[storyboard instantiateViewControllerWithIdentifier:@"DashboardVC"];
    [[SlideNavigationController sharedInstance] pushViewController:second animated:YES];
}




@end
