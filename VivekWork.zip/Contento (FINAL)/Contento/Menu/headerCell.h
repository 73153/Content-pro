//
//  headerCell.h
//  Contento
//
//  Created by aadil on 08/02/16.
//  Copyright © 2016 Zaptech. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface headerCell : UITableViewCell
@property IBOutlet UILabel *title;
@end
