//
//  CategoryButtons.m
//  Contento
//
//  Created by aadil on 02/12/15.
//  Copyright © 2015 Zaptech. All rights reserved.
//

#import "CategoryButtons.h"

@implementation CategoryButtons

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
