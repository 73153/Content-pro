//
//  CategoryButtons.h
//  Contento
//
//  Created by aadil on 02/12/15.
//  Copyright © 2015 Zaptech. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CategoryButtons : UIButton
@property NSString *name;
@end
